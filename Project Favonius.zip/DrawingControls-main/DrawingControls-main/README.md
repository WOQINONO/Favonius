# ShapeEx
VB6 Shape and Line controls replacements. With antialiasing and new figures. Based on GDI+  
It can be used as a direct replacement of the original VB6 controls.  

[For more information please go to vbForums thread](https://www.vbforums.com/showthread.php?899337-DrawingControls-for-VB6-Shape-and-Line-controls-replacement-with-anti-aliasing)

![imagen](https://user-images.githubusercontent.com/42319299/222857086-893ae611-5b9d-4621-9062-a6a6abd5a8c0.png)

![imagen](https://user-images.githubusercontent.com/42319299/222829138-82f00818-dd54-4e6f-8d83-090c8713abff.png)

