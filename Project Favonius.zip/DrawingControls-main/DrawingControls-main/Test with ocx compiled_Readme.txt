Run the file:

DrwCtrl1 Register (run as Admin).bat

that is in the 'ocx' folder to be able to use the OCX 

And run the IDE as admin too, at least the first time.